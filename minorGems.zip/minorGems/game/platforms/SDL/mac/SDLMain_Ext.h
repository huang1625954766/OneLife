#ifdef __cplusplus
extern "C" {
#endif

extern void NSMenu_setMenuBarVisible(int flag);

#ifdef __cplusplus
}
#endif