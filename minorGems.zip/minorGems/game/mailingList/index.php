<FORM ACTION="server.php" METHOD="post">
    <INPUT TYPE="password" MAXLENGTH=20 SIZE=20 NAME="password">
    <INPUT TYPE="hidden" NAME="action" VALUE="show_data">
	        <INPUT TYPE="Submit" VALUE="login">
    </FORM>