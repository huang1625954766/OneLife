void loadFile( const char* fileName, long sizeInBytes, unsigned char* byteDestPtr);

void loadRawFile( const char* fileName, long sizeInBytes, unsigned char* byteDestPtr);