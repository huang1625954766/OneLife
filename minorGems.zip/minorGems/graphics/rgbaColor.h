#ifndef RGBACOLOR_INCLUDED
#define RGBACOLOR_INCLUDED


typedef struct rgbaColor {
        unsigned char r;
        unsigned char g;
        unsigned char b;
        unsigned char a;
    } rgbaColor;


#endif
