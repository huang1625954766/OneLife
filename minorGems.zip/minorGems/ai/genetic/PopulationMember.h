/*
 * Modification History
 *
 * 2000-October-12		Jason Rohrer
 * Created.
 */
 
#ifndef POPULATION_MEMBER_INCLUDED
#define POPULATION_MEMBER_INCLUDED
 
/**
 * Marker interface for members of a population.
 *
 * @author Jason Rohrer
 */  
class PopulationMember {
	};
	
#endif
